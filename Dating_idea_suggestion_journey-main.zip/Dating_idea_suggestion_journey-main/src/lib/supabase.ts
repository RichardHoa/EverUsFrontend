import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function saveDateCompletion(
  activityKey: string,
  activityName: string,
  matchPercentage: number,
  userVector: number[],
  activityVector: number[]
) {
  const { error } = await supabase.from('date_completions').insert({
    activity_key: activityKey,
    activity_name: activityName,
    match_percentage: matchPercentage,
    user_vector: userVector,
    activity_vector: activityVector,
  });

  if (error) {
    console.error('Error saving date completion:', error);
    throw error;
  }
}

export async function getCompletionStats() {
  const { data, error } = await supabase
    .from('date_completions')
    .select('activity_key, match_percentage, completed_at')
    .order('completed_at', { ascending: false });

  if (error) {
    console.error('Error fetching completion stats:', error);
    return [];
  }

  return data;
}

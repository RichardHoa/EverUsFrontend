import React, { useEffect, useRef } from 'react';
import { ACTIVITIES, DIMENSIONS } from '../lib/activities';

interface MathVisualizationProps {
  userVector: number[];
  userVectorP2?: number[] | null;
  activityVector: number[];
  activityTheme: {
    primary: string;
    secondary: string;
    accent: string;
  };
  selectedKey?: string;
}

export const MathVisualization: React.FC<MathVisualizationProps> = ({
  userVector,
  userVectorP2,
  activityVector,
  activityTheme,
  selectedKey = 'cooking',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Get all activities with their distances
  const activitiesWithDistances = Object.entries(ACTIVITIES)
    .map(([key, activity]) => {
      const distance = Math.sqrt(
        userVector.reduce((sum, v, i) => sum + Math.pow(v - activity.vec[i], 2), 0)
      );
      return {
        key,
        name: activity.name,
        vec: activity.vec,
        distance: distance,
        distanceSquared: distance * distance,
      };
    })
    .sort((a, b) => a.distance - b.distance);

  const selectedActivity = ACTIVITIES[selectedKey];
  const selectedDist = activitiesWithDistances.find((a) => a.key === selectedKey);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedDist) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const scale = 40;

    // Clear with gradient background
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, 'rgba(243, 232, 255, 0.05)');
    gradient.addColorStop(1, 'rgba(219, 234, 254, 0.05)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 50) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height);
      ctx.stroke();
    }
    for (let i = 0; i < canvas.height; i += 50) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width, i);
      ctx.stroke();
    }

    // Normalize vectors for 2D visualization (use first 2 dimensions)
    const maxVal = Math.max(...userVector, ...selectedDist.vec);
    const userNorm = userVector.slice(0, 2).map((v) => (v / maxVal) * 100);
    const activityNorm = selectedDist.vec.slice(0, 2).map((v) => (v / maxVal) * 100);

    // Draw approximation plane (rectangle)
    const planeX1 = centerX - 120;
    const planeY1 = centerY - 120;
    const planeX2 = centerX + 120;
    const planeY2 = centerY + 120;

    ctx.fillStyle = 'rgba(59, 130, 246, 0.08)';
    ctx.fillRect(planeX1, planeY1, 240, 240);
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
    ctx.lineWidth = 2;
    ctx.strokeRect(planeX1, planeY1, 240, 240);

    // User vector point
    const userX = centerX + userNorm[0] * 1.2 - 120;
    const userY = centerY + userNorm[1] * 1.2 - 120;

    ctx.strokeStyle = '#EC4899';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(userX, userY);
    ctx.stroke();

    ctx.fillStyle = '#EC4899';
    ctx.beginPath();
    ctx.arc(userX, userY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Activity vector point
    const actX = centerX + activityNorm[0] * 1.2 - 120;
    const actY = centerY + activityNorm[1] * 1.2 - 120;

    ctx.strokeStyle = activityTheme.primary;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(actX, actY);
    ctx.stroke();

    ctx.fillStyle = activityTheme.primary;
    ctx.beginPath();
    ctx.arc(actX, actY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Distance line (dashed)
    ctx.strokeStyle = 'rgba(255, 100, 100, 0.7)';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(userX, userY);
    ctx.lineTo(actX, actY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Origin
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(centerX, centerY, 4, 0, Math.PI * 2);
    ctx.fill();

    // Labels
    ctx.font = 'bold 12px Inter, sans-serif';
    ctx.fillStyle = '#EC4899';
    ctx.textAlign = 'left';
    ctx.fillText('v (your preferences)', userX + 12, userY - 5);

    ctx.fillStyle = activityTheme.primary;
    ctx.fillText(`a (${selectedActivity.name})`, actX + 12, actY + 12);

    ctx.fillStyle = 'rgba(255, 100, 100, 0.8)';
    ctx.textAlign = 'center';
    ctx.font = 'bold 11px Inter, sans-serif';
    const midX = (userX + actX) / 2;
    const midY = (userY + actY) / 2;
    ctx.fillText(`d = ${selectedDist.distance.toFixed(1)}`, midX, midY - 12);
  }, [userVector, selectedDist, selectedActivity, activityTheme]);

  return (
    <div className="space-y-6 bg-gradient-to-br from-white/40 to-white/20 backdrop-blur-sm rounded-3xl p-8 border border-white/60">
      {/* Title with math symbols */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <span>📐</span> How the Maths Works
        </h2>
        <p className="text-sm text-gray-700">
          Your couple's preferences form a <span className="font-mono font-bold text-pink-600">vector v</span>, each activity has its own <span className="font-mono font-bold" style={{ color: ACTIVITIES[selectedKey || 'cooking'].theme.primary }}>vector a</span>. We find the activity that minimizes the distance.
        </p>
      </div>

      {/* Canvas visualization */}
      <div className="rounded-2xl shadow-lg overflow-hidden border-2 border-blue-300 bg-gray-950">
        <canvas
          ref={canvasRef}
          className="w-full bg-gray-950"
          style={{ height: '280px', display: 'block' }}
        />
      </div>

      {/* Formula section */}
      <div className="grid grid-cols-2 gap-6">
        <div className="p-5 rounded-xl bg-blue-50 border-2 border-blue-300">
          <p className="text-xs text-gray-600 mb-2 font-bold">Least Squares Formula</p>
          <p className="text-lg font-mono font-bold text-blue-700">x = argmin ||Ax - v||²</p>
          <p className="text-xs text-gray-600 mt-2">Find activity that minimizes distance</p>
        </div>

        <div className="p-5 rounded-xl bg-gradient-to-br from-pink-50 to-rose-50 border-2 border-pink-300">
          <p className="text-xs text-gray-600 mb-2 font-bold">Your Best Match</p>
          <p className="text-lg font-bold text-pink-700">{selectedDist?.name}</p>
          <p className="text-sm font-mono text-rose-600 mt-1">Distance: {selectedDist?.distance.toFixed(2)}</p>
        </div>
      </div>

      {/* Activity rankings table */}
      <div className="rounded-2xl overflow-hidden border-2 border-gray-300 bg-white/60 backdrop-blur-sm">
        <div className="px-6 py-4 bg-gradient-to-r from-gray-900 to-gray-800 border-b border-gray-700">
          <h3 className="text-white font-bold text-sm">Activity Database: Finding Best Approximation</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-100">
                <th className="px-4 py-3 text-left text-gray-700 font-bold">Activity</th>
                {DIMENSIONS.map((dim) => (
                  <th key={dim.key} className="px-4 py-3 text-center text-gray-600 font-bold text-xs">
                    {dim.icon}
                  </th>
                ))}
                <th className="px-4 py-3 text-center text-orange-600 font-bold">||v-a||²</th>
              </tr>
            </thead>
            <tbody>
              {activitiesWithDistances.slice(0, 6).map((activity, idx) => {
                const isSelected = activity.key === selectedKey;
                return (
                  <tr
                    key={activity.key}
                    className={`border-b border-gray-100 transition-colors ${
                      isSelected
                        ? 'bg-gradient-to-r from-pink-50 to-transparent'
                        : idx % 2 === 0
                        ? 'bg-gray-50'
                        : 'bg-white'
                    }`}
                  >
                    <td className={`px-4 py-3 font-semibold ${isSelected ? 'text-pink-700' : 'text-gray-700'}`}>
                      {isSelected && '→ '}{activity.name}
                    </td>
                    {activity.vec.map((val, i) => (
                      <td key={i} className={`px-4 py-3 text-center ${isSelected ? 'font-bold text-blue-700' : 'text-gray-600'}`}>
                        {val}
                      </td>
                    ))}
                    <td className={`px-4 py-3 text-center font-bold ${isSelected ? 'text-orange-600 text-base' : 'text-gray-500'}`}>
                      {activity.distanceSquared.toFixed(1)}
                    </td>
                  </tr>
                );
              })}
              {/* User vector row */}
              <tr className="bg-gray-900 text-white font-bold">
                <td className="px-4 py-3">Your Vector (v)</td>
                {userVector.map((val, i) => (
                  <td key={i} className="px-4 py-3 text-center">
                    {val}
                  </td>
                ))}
                <td className="px-4 py-3 text-center">—</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual explanation */}
      <div className="grid grid-cols-3 gap-4 text-sm">
        <div className="p-4 rounded-lg bg-pink-50 border border-pink-300 text-center">
          <p className="text-2xl mb-2">v</p>
          <p className="font-semibold text-gray-900">Your Preference Vector</p>
          <p className="text-xs text-gray-600 mt-1">What your couple wants</p>
        </div>
        <div className="p-4 rounded-lg bg-blue-50 border border-blue-300 text-center">
          <p className="text-2xl mb-2">a</p>
          <p className="font-semibold text-gray-900">Activity Vector</p>
          <p className="text-xs text-gray-600 mt-1">What activity offers</p>
        </div>
        <div className="p-4 rounded-lg bg-orange-50 border border-orange-300 text-center">
          <p className="text-2xl mb-2">||v-a||²</p>
          <p className="font-semibold text-gray-900">Squared Distance</p>
          <p className="text-xs text-gray-600 mt-1">Measurement of fit</p>
        </div>
      </div>
    </div>
  );
};

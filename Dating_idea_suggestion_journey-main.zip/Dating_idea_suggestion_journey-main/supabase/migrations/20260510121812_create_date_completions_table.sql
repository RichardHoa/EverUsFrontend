/*
  # Create date completions tracking table

  1. New Tables
    - `date_completions`
      - `id` (uuid, primary key)
      - `activity_key` (text) - identifier of the activity completed
      - `activity_name` (text) - display name
      - `match_percentage` (integer) - match score when started
      - `completed_at` (timestamp)
      - `user_vector` (jsonb) - user's preference vector at time of completion [romance, adventure, creativity, indoor, energy]
      - `activity_vector` (jsonb) - activity's vector [romance, adventure, creativity, indoor, energy]

  2. Security
    - Enable RLS (public access since no auth, but structure-ready for future)
    - Add policy for reading all completions
    - Add policy for inserting completions
*/

CREATE TABLE IF NOT EXISTS date_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  activity_key text NOT NULL,
  activity_name text NOT NULL,
  match_percentage integer NOT NULL,
  user_vector jsonb NOT NULL,
  activity_vector jsonb NOT NULL,
  completed_at timestamptz DEFAULT now()
);

ALTER TABLE date_completions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read date completions"
  ON date_completions FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert date completions"
  ON date_completions FOR INSERT
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_activity_key ON date_completions(activity_key);
CREATE INDEX IF NOT EXISTS idx_completed_at ON date_completions(completed_at DESC);
